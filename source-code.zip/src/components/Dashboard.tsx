import React from 'react';
import { Lead } from '../types';
import { cn } from '../lib/utils';
import { Building2, IndianRupee, Phone, Mail, Clock, ShieldCheck, AlertCircle } from 'lucide-react';

interface DashboardProps {
  leads: Lead[];
  onUpdateStatus: (id: string, status: Lead['status']) => void;
}

export function Dashboard({ leads, onUpdateStatus }: DashboardProps) {
  const getStatusColor = (status: Lead['status']) => {
    switch (status) {
      case 'New': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Contacted': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Site Visit': return 'bg-indigo-100 text-indigo-700 border-indigo-200';
      case 'Booked': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Lost': return 'bg-rose-100 text-rose-700 border-rose-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="flex-1 p-8 max-w-7xl mx-auto w-full overflow-y-auto styled-scrollbar">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-800">Sales Dashboard</h1>
        <p className="text-slate-500 mt-1">Manage leads, track statuses, and monitor updates.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Leads', value: leads.length, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: 'New', value: leads.filter(l => l.status === 'New').length, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Site Visits', value: leads.filter(l => l.status === 'Site Visit').length, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Booked', value: leads.filter(l => l.status === 'Booked').length, color: 'text-emerald-600', bg: 'bg-emerald-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">{stat.label}</p>
              <p className="text-3xl font-bold text-slate-800 mt-2">{stat.value}</p>
            </div>
            <div className={cn("w-12 h-12 rounded-full flex items-center justify-center", stat.bg)}>
              <Building2 className={cn("w-6 h-6", stat.color)} />
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                <th className="px-6 py-4 font-semibold">Lead Contact</th>
                <th className="px-6 py-4 font-semibold">Requirement</th>
                <th className="px-6 py-4 font-semibold">Date Registered</th>
                <th className="px-6 py-4 font-semibold">Status</th>
                <th className="px-6 py-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {leads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-500">
                    <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-3" />
                    <p className="text-base font-medium text-slate-600">No leads found</p>
                    <p className="text-sm mt-1">Start by capturing some leads in the Enquiry Form.</p>
                  </td>
                </tr>
              ) : (
                leads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-800 text-sm mb-1">{lead.name}</div>
                      <div className="flex items-center gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {lead.phone}</span>
                        <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {lead.email}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-slate-700 font-medium mb-1 flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" /> {lead.propertyInterest}
                      </div>
                      <div className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                        <IndianRupee className="w-3 h-3" /> {lead.budget}
                      </div>
                    </td>
                    <td className="px-6 py-4 truncate text-sm text-slate-500 whitespace-nowrap">
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        {new Date(lead.timestamp).toLocaleDateString('en-IN', {
                          day: 'numeric', month: 'short', year: 'numeric',
                          hour: 'numeric', minute: '2-digit'
                        })}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-2 items-start">
                        <span className={cn("px-2.5 py-1 text-xs font-semibold rounded-full border w-fit", getStatusColor(lead.status))}>
                          {lead.status}
                        </span>
                        {lead.priority && (
                          <span className={cn("px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded border", 
                            lead.priority === 'High' ? "bg-red-50 text-red-600 border-red-200" :
                            lead.priority === 'Medium' ? "bg-amber-50 text-amber-600 border-amber-200" :
                            "bg-blue-50 text-blue-600 border-blue-200"
                          )}>
                            {lead.priority} Priority
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <select 
                        value={lead.status}
                        onChange={(e) => onUpdateStatus(lead.id, e.target.value as Lead['status'])}
                        className="text-sm border border-slate-200 bg-white text-slate-700 rounded-lg px-2 py-1.5 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      >
                        <option value="New">New</option>
                        <option value="Contacted">Contacted</option>
                        <option value="Site Visit">Site Visit</option>
                        <option value="Booked">Booked</option>
                        <option value="Lost">Lost</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
